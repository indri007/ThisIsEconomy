# 📦 Zenodo Open Science Replication Package
## Digital Sarcasm, Networked Affect, and the Algorithmic Oracle: Investigating Citizen Resistance to Indonesia's Free Nutritious Meal (MBG) Program on Platform X

**Persistent Identifier (DOI):** [10.5281/zenodo.11029482](https://doi.org/10.5281/zenodo.11029482)  
**Authors:** Indri Anjar Kartika Sari¹, Catur Suratnoaji¹, Agus Widiyarta¹  
*¹ Department of Communication Science, Universitas Pembangunan Nasional 'Veteran' Jawa Timur, Indonesia*  
**Corresponding Author:** `indrianjar@gmail.com`  
**License:** Code: MIT License | Datasets & Documentation: Creative Commons Attribution 4.0 International (CC-BY-4.0)  
**Permanent Development Mirror:** https://github.com/indri007/ThisIsEconomy

---

## 🏛️ Compliance with ICA & Oxford University Press Open Science Mandates

This package satisfies the rigorous replication and archiving requirements of the **International Communication Association (ICA)** and the **Journal of Computer-Mediated Communication (Oxford University Press)**:
1. **FAIR Data Principles**: Findable (via persistent DOI), Accessible (open access without embargo), Interoperable (standard CSV, JSON, and CFF formats), and Reusable.
2. **AoIR 3.0 Ethical Anonymization**: All public microblogging usernames of private citizens are rigorously pseudonymized using SHA-256 keyed HMAC hashes to safeguard subject physical privacy under Indonesia's Electronic Information and Transactions Law (UU ITE), while institutional state accounts (`@prabowo`, `@gibran_tweet`, `@bgn_ri`, `@grok`) remain transparently disclosed.
3. **Multi-Annotator Gold Standard**: Full 100-sample adjudicated corpus evaluated under tri-rater protocol (Fleiss' κ = 0.8442, Krippendorff's α = 0.8447).

---

## 📁 Directory Structure

```text
zenodo_replication_package/
├── .zenodo.json              # DataCite / Zenodo metadata manifest
├── CITATION.cff              # GitHub / Zenodo citation file format
├── LICENSE                   # Open science license terms
├── requirements.txt          # Python runtime dependencies
├── README.md                 # This replication manual
├── data/                     # Immutable research benchmark datasets
│   ├── multi_annotator_batch_100_GOLD.csv
│   ├── canonical_macro_topology_metrics.csv
│   ├── canonical_top25_actors_aoir_pseudonymized.csv
│   ├── canonical_community_distribution.csv
│   ├── dynamic_temporal_network_phases.csv
│   ├── spatial_epidemiological_provincial_benchmark.csv
│   ├── absa_aspect_category_token_benchmark.csv
│   ├── astroturfing_hourly_circadian_distribution.csv
│   └── cross_platform_affordance_matrix.csv
├── scripts/                  # Pure replication calculation engines
│   ├── run_multi_annotator_agreement_validation.py
│   ├── run_minority_class_imbalance_audit.py
│   ├── run_astroturfing_and_bot_audit.py
│   ├── run_cross_platform_validity_audit.py
│   ├── run_dynamic_temporal_network_audit.py
│   ├── run_spatial_epidemiological_audit.py
│   └── run_absa_acsa_span_audit.py
├── reports/                  # Detailed methodological audit reports (.md)
│   ├── MULTI_ANNOTATOR_GOLD_VALIDATION_REPORT.md
│   ├── MINORITY_CLASS_IMBALANCE_AUDIT_REPORT.md
│   ├── AOIR_ETHICAL_PSEUDONYMIZATION_REPORT.md
│   ├── ASTROTURFING_AND_BOT_AUDIT_REPORT.md
│   ├── CROSS_PLATFORM_ECOLOGICAL_VALIDITY_REPORT.md
│   ├── DYNAMIC_TEMPORAL_NETWORK_REPORT.md
│   ├── SPATIAL_EPIDEMIOLOGICAL_CORRELATION_REPORT.md
│   └── ABSA_ACSA_VS_SPAN_LEVEL_REPORT.md
└── figures/                  # Publication-quality 300 DPI visualizations
    ├── 16_nodexl_graph_visualization.png
    ├── 17_macro_topology_metrics.png
    ├── 18_actor_centrality_typology.png
    ├── 19_community_echo_chambers.png
    ├── 10_absa_thematic.png
    ├── grafik_master_indobert_dan_rumus_tesis.png
    └── indobert_monthly_emotion_timeline_2026.png
```

---

## ⚡ Quick Replication (One-Line Execution)

To reproduce all 10 empirical verification points from a fresh terminal:

```bash
# 1. Clone repository or extract Zenodo archive
git clone https://github.com/indri007/ThisIsEconomy.git
cd ThisIsEconomy

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run full automated test and audit suite
pytest -v
```

All 68 tests will pass in under 5 seconds, validating every metric published in the manuscript.
